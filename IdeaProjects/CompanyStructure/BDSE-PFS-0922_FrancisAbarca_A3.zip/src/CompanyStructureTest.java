import static org.junit.jupiter.api.Assertions.*;

class CompanyStructureTest {
    BusinessLead BL = new BusinessLead("Amy Wood");
    TechnicalLead TL = new TechnicalLead("Satya Nadella");
    SoftwareEngineer SE = new SoftwareEngineer("Kasey");
    Accountant AC = new Accountant("Bill");

}