clear

javac SourceCode/Main.java && java SourceCode/Main.java
