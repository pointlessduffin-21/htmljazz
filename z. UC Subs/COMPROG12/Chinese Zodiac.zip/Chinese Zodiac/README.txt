To run this application, heres how:

- On Windows
	- Just double click the run.bat
	or
	- Open Command Prompt in there by clicking on the address bar in explorer then typing cmd
	- Type "run.bat"

- On macOS/Linux
	- Open the Terminal
	- Change to this Directory
	- Change its permissions: "sudo chmod +x run.sh"
	- Type "run.sh"

If there are any issues, feel free to contact:
- f.abarca@yeems214.xyz
