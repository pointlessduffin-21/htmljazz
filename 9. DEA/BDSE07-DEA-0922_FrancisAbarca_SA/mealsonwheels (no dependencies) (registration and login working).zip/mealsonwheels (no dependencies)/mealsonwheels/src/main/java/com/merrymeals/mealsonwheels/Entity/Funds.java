package com.merrymeals.mealsonwheels.Entity;

public class Funds {

}
