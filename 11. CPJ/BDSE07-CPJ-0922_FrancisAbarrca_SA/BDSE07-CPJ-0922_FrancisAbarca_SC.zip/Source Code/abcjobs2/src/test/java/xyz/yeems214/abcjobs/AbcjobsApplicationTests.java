package xyz.yeems214.abcjobs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AbcjobsApplicationTests {

    @Test
    void contextLoads() {
    }

}
