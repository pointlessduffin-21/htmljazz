package com.yeems214.abcarportal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AbCarPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
