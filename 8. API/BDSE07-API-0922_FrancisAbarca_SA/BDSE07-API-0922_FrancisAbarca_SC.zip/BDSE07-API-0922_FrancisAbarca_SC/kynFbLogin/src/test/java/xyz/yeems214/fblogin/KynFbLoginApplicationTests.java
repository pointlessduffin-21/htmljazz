package xyz.yeems214.fblogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KynFbLoginApplicationTests {

    @Test
    void contextLoads() {
    }

}
