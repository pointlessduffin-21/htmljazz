package xyz.yeems214.fblogin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KynFbLoginApplication {

    public static void main(String[] args) {
        SpringApplication.run(KynFbLoginApplication.class, args);
    }

}
