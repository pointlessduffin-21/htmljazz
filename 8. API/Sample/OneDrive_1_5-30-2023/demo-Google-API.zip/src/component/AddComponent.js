
import React,{Component } from 'react';


class AddComponent extends Component{

    render(){
        return (
            <div>
                <h1>Add Product </h1>
                
            </div>
        )
    }
}

export default AddComponent;
