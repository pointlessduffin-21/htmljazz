
import React,{Component} from 'react';
import GoogleLogin, { MGoogleLogin } from './component/GoogleLogin';

class App extends Component{
  
  
    render(){
      return(
       
<div>
       <GoogleLogin></GoogleLogin>

        </div>
      )
    }
}

export default App;