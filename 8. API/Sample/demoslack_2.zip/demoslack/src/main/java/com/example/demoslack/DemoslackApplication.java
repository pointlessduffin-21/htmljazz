package com.example.demoslack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoslackApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoslackApplication.class, args);
	}

}
