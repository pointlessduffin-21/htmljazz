package xyz.yeems214.xyzcars;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XyzcarsApplicationTests {

	@Test
	void contextLoads() {
	}

}
