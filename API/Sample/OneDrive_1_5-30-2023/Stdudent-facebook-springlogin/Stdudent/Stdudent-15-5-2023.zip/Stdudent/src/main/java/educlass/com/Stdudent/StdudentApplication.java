package educlass.com.Stdudent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StdudentApplication {

	public static void main(String[] args) {
		SpringApplication.run(StdudentApplication.class, args);
	}

}
