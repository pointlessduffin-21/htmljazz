package xyz.yeems214.xyzcars;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XyzcarsApplication {

	public static void main(String[] args) {
		SpringApplication.run(XyzcarsApplication.class, args);
	}

}
