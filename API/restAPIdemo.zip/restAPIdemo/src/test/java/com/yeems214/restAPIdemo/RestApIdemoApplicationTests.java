package com.yeems214.restAPIdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApIdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
